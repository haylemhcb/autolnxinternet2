/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * main.c
 * Copyright (C) 2019 Haylem Candelario Bauza <haylemhcb@gmail.com>
 * 
 * autolnxinternet is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * autolnxinternet is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <config.h>
#include <gtk/gtk.h>
#include "apihack.h"
#include <math.h>


#include <glib/gi18n.h>

#define RUTAIMG "/usr/local/share/autolnxinternet/ui"

struct GLOB
{
   gchar *signal;
   gchar *intfcli;
   gchar *intfpub;
   gint iniciado; /* Si ha iniciado el ataque */
   NET *net;
   gchar *home;
   gchar *headernet;
   gchar *pasarl;
   gchar *portcap;
   gchar dirconf[250];
   gchar *dns1;
   gchar *dns2;
   gchar *dns3;
   gchar *dns4;
   gchar *dns5;
   gchar *essidcli;
   gchar *bssid;
   gchar *frag;
   gchar *rts;
   gchar *canal;
   gchar *region;
   gchar *rate;
   gchar *mtu;
} vars;



typedef struct _Private Private;
struct _Private
{
	/* ANJUTA: Widgets declaration for autolnxinternet.ui - DO NOT REMOVE */
	GtkWidget* txtregion;
	GtkWidget* txtrate;
	GtkWidget* txtmtu;
	GtkWidget* lblpuntoap;
	GtkWidget* lblip;
	GtkWidget* lblmac;

	GtkWidget* imgdisponib;
	GtkWidget* lblssid;
	GtkWidget* lblreint;
	GtkWidget* txtnet;
	GtkWidget* imgstatus;
	GtkWidget* txtcanalcon;
	GtkWidget* txtrts;
	GtkWidget* txtfrag;
	GtkWidget* txtdns5;
	GtkWidget* txtdns4;
	GtkWidget* txtdns3;
	GtkWidget* txtdns2;
	GtkWidget* txtdns1;
	GtkWidget* txtanclabssid;
	GtkWidget* txtnombrewifi;
	GtkWidget* txtpuertocap;
	GtkWidget* txtpasarl;
	GtkWidget* __glade_unnamed_5;
	GtkWidget* prg;
	GtkWidget* btnparar;
	GtkWidget* btniniciar;
	GtkWidget* __glade_unnamed_11;
	GtkWidget* btnload;
	GtkWidget* btnsave;
	GtkWidget* txtinterfpub;
	GtkWidget* lblsignal;
	GtkWidget* txtinterfcli;
};

static Private* priv = NULL;

/* For testing purpose, define TEST to use the local (not installed) ui file */

/*#define TEST*/
#ifdef TEST
#define UI_FILE "src/autolnxinternet.ui"
#else
#define UI_FILE PACKAGE_DATA_DIR"/ui/autolnxinternet.ui"
#endif
#define TOP_WINDOW "window"

/* Signal handlers */
/* Note: These may not be declared static because signal autoconnection
 * only works with non-static methods
 */

/* Called when the window is closed */
void
on_window_destroy (GtkWidget *widget, gpointer data)
{
	vars.iniciado = 0;
    net_stop_traffic_gen();
	net_clean_dns_file(vars.net);
	gtk_main_quit ();
}

void
on_guardar (GtkWidget *widget, gpointer data)
{
   void guardaconfig(void);
   guardaconfig();
}

void
on_parar (GtkWidget *widget, gpointer data)
{
  vars.iniciado = 0;
  VARS.emergencyexit = 1; /* Parada de emergencia api hack */
  gtk_image_set_from_file(priv->imgdisponib, RUTAIMG"/senialok.jpeg");
  net_stop_traffic_gen();
  contador = 1;
  sys_pkill ("tcpdump");
  gtk_label_set_text(GTK_LABEL(priv->lblip), "---");
  gtk_label_set_text(GTK_LABEL(priv->lblmac), "---");
  gtk_label_set_text(GTK_LABEL(priv->lblssid), "---");
  gtk_label_set_text(GTK_LABEL(priv->lblpuntoap), "---");
}

void
on_iniciar (GtkWidget *widget, gpointer data)
{
	void leer_senial(void);
	void asociar(void);
	gpointer ataquelnx (gpointer);
	void leer_campos(void);
	void verificainternet(void);

	GThread *autolnx = NULL;

	leer_campos();
	void leecont(void);
    
	if(vars.iniciado == 1) return;
	remove("/tmp/lnxgoog");
    remove("/tmp/datoswifi");
	sys_pkill ("tcpdump");
	contador = 1;

    vars.iniciado = 1;
	VARS.emergencyexit = 0;


	vars.net = net_new ();
	net_set_interf(vars.net, vars.intfcli);
	
    sys_wifi_set_country(vars.region);
	net_wifi_set_retry_limit(vars.net, "30");
	net_wifi_set_rate(vars.net, vars.rate);
	net_wifi_set_channel(vars.net, vars.canal);
	
	net_set_mtu (vars.net, "2304");
	net_set_gateway (vars.net, vars.pasarl);
	net_cap_set_timeout (vars.net, 10);
	net_cap_set_monitor(vars.net, "1");
	net_cap_set_port(vars.net, vars.portcap);
	net_cap_set_range(vars.net, vars.headernet);
	net_clean_dns_file(vars.net);
	net_add_dns(vars.net, vars.dns1);
	net_add_dns(vars.net, vars.dns2);
	net_add_dns(vars.net, vars.dns3);
	net_add_dns(vars.net, vars.dns4);
	net_add_dns(vars.net, vars.dns5);
	net_wifi_set_ssid(vars.net, vars.essidcli);

	autolnx = g_thread_try_new ("ataquelnx", ataquelnx, NULL, NULL);
    if(autolnx == NULL) return;

	g_timeout_add_seconds(2, (GSourceFunc) leer_senial, NULL);
	g_timeout_add_seconds(3, (GSourceFunc) asociar, NULL);
    g_timeout_add_seconds(2, (GSourceFunc) leecont, NULL);

	
}

void guardaconfig(void)
{
  void leer_campos(void);
	
  gchar file[250] = {'\0'};

  leer_campos();
	
  strcpy(file, vars.dirconf);
  strcat(file, "/intfcli");
  file_save_data(file, vars.intfcli);

  strcpy(file, vars.dirconf);
  strcat(file, "/intfpub");
  file_save_data(file, vars.intfpub);

  strcpy(file, vars.dirconf);
  strcat(file, "/headernet");
  file_save_data(file, vars.headernet);

  strcpy(file, vars.dirconf);
  strcat(file, "/gateway");
  file_save_data(file, vars.pasarl);

  strcpy(file, vars.dirconf);
  strcat(file, "/puertocap");
  file_save_data(file, vars.portcap);

  strcpy(file, vars.dirconf);
  strcat(file, "/dns1");
  file_save_data(file, vars.dns1);

  strcpy(file, vars.dirconf);
  strcat(file, "/dns2");
  file_save_data(file, vars.dns2);

  strcpy(file, vars.dirconf);
  strcat(file, "/dns3");
  file_save_data(file, vars.dns3);

  strcpy(file, vars.dirconf);
  strcat(file, "/dns4");
  file_save_data(file, vars.dns4);

  strcpy(file, vars.dirconf);
  strcat(file, "/dns5");
  file_save_data(file, vars.dns5);

  strcpy(file, vars.dirconf);
  strcat(file, "/nombrewifi");
  file_save_data(file, vars.essidcli);

  strcpy(file, vars.dirconf);
  strcat(file, "/anclabssid");
  file_save_data(file, vars.bssid);

  strcpy(file, vars.dirconf);
  strcat(file, "/frag");
  file_save_data(file, vars.frag);

  strcpy(file, vars.dirconf);
  strcat(file, "/rts");
  file_save_data(file, vars.rts);

  strcpy(file, vars.dirconf);
  strcat(file, "/canal");
  file_save_data(file, vars.canal);

  strcpy(file, vars.dirconf);
  strcat(file, "/region");
  file_save_data(file, vars.region);

  strcpy(file, vars.dirconf);
  strcat(file, "/rate");
  file_save_data(file, vars.rate);

  strcpy(file, vars.dirconf);
  strcat(file, "/mtu");
  file_save_data(file, vars.mtu);
}

void leer_campos(void)
{
	if(strcmp(gtk_entry_get_text(GTK_ENTRY(priv->txtinterfcli)), "") == 0) gtk_entry_set_text(GTK_ENTRY(priv->txtinterfcli), "wlan0");
	
    vars.intfcli = gtk_entry_get_text(GTK_ENTRY(priv->txtinterfcli));

	vars.intfpub = gtk_entry_get_text(GTK_ENTRY(priv->txtinterfpub));
	vars.headernet = gtk_entry_get_text(GTK_ENTRY(priv->txtnet));
	vars.pasarl = gtk_entry_get_text(GTK_ENTRY(priv->txtpasarl));
	vars.portcap = gtk_entry_get_text(GTK_ENTRY(priv->txtpuertocap));
	vars.dns1 = gtk_entry_get_text(GTK_ENTRY(priv->txtdns1));
	vars.dns2 = gtk_entry_get_text(GTK_ENTRY(priv->txtdns2));
	vars.dns3 = gtk_entry_get_text(GTK_ENTRY(priv->txtdns3));
	vars.dns4 = gtk_entry_get_text(GTK_ENTRY(priv->txtdns4));
	vars.dns5 = gtk_entry_get_text(GTK_ENTRY(priv->txtdns5));
	vars.essidcli = gtk_entry_get_text(GTK_ENTRY(priv->txtnombrewifi));
	vars.bssid = gtk_entry_get_text(GTK_ENTRY(priv->txtanclabssid));
	vars.frag = gtk_entry_get_text(GTK_ENTRY(priv->txtfrag));
	vars.rts = gtk_entry_get_text(GTK_ENTRY(priv->txtrts));
	vars.canal = gtk_entry_get_text(GTK_ENTRY(priv->txtcanalcon));
	vars.mtu = gtk_entry_get_text(GTK_ENTRY(priv->txtmtu));
	vars.region = gtk_entry_get_text(GTK_ENTRY(priv->txtregion));
	vars.rate = gtk_entry_get_text(GTK_ENTRY(priv->txtrate));
}

gpointer ataquelnx (gpointer data)
{
	
   while(vars.iniciado == 1)
   {

	   
	   gtk_label_set_text(GTK_LABEL(priv->lblssid), "---");
       /* Actualizar icono de estado */
	   gtk_image_set_from_file(priv->imgstatus, RUTAIMG"/estadoatacando.jpeg");
       gtk_image_set_from_file(priv->imgdisponib, RUTAIMG"/senialok.jpeg");
       sleep(1);
	   if(vars.iniciado == 0)  break;
	   /* Actualizar icono de estado */
	   gtk_image_set_from_file(priv->imgstatus, RUTAIMG"/estadosnifando.jpeg");
       net_cap_dump(vars.net);	
	   if(vars.iniciado == 0)  break;
	   if(strcmp(net_cap_get_ip (vars.net), "PARADO") == 0) break; 
       if(strcmp(net_cap_get_ip (vars.net), "NOIP") == 0) continue; 

	   /* Establecer ip y mac  a la red */
	   if(vars.iniciado == 0)  break;
	   gtk_image_set_from_file(priv->imgstatus, RUTAIMG"/estadoactdatos.png");
	   net_set_ip (vars.net, net_cap_get_ip(vars.net));
       if(strcmp(net_cap_get_ip (vars.net), "NOIP") == 0) continue; 
	   net_set_mac (vars.net, net_cap_get_mac(vars.net));
	   net_apply_config(vars.net);


	   /* Generador de trafico */
	   gtk_image_set_from_file(priv->imgstatus, RUTAIMG"/suplantacion.png");
	   if(net_keep_traffic_active() == 1) continue;


	   if(vars.iniciado == 0) break;
   }
	gtk_label_set_text(GTK_LABEL(priv->lblsignal), "---");
	gtk_image_set_from_file(priv->imgstatus, RUTAIMG"/estadoespera.png");
	gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(priv->prg), 0.0);
	return;
}

void leecont(void)
{
 char buf[80] = {'\0'};

 if(vars.iniciado == 0) return;
 if(vars.net->cap.working == 1) return;	
 if(net_isdown_interf (vars.net) == 1) return;

 if(contador == 0)
    gtk_image_set_from_file(priv->imgdisponib, RUTAIMG"/ok.png");
	
 if(contador >= 20)
    gtk_image_set_from_file(priv->imgdisponib, RUTAIMG"/nointernet.png");

 if(contador >= 50)
    gtk_image_set_from_file(priv->imgdisponib, RUTAIMG"/malisima.png");


	puts("Leyendo contador");
	
 gcvt(contador, 3, buf);
 gtk_label_set_text(GTK_LABEL(priv->lblreint), (gchar *)buf);
 
}



void leer_senial(void)
{
  const gchar *ipact = NULL;
  const gchar *macact = NULL;
  const gchar *apact = NULL;
  if(vars.iniciado == 0) return;
  if(vars.net->cap.working == 1) return;	
  if(net_isdown_interf (vars.net) == 1)
  {
	  vars.signal = "Desconectado";
	  return;
  }
 
  vars.signal = net_wifi_get_signal(vars.net);
  if(vars.signal == NULL) vars.signal = "0";
  ipact = net_get_ip (vars.net);
  macact = net_get_mac (vars.net);
  apact = net_wifi_get_bssid (vars.net);
  gtk_label_set_text(GTK_LABEL(priv->lblsignal), vars.signal);
  gtk_label_set_text(GTK_LABEL(priv->lblssid), net_wifi_get_ssid (vars.net));
  gtk_label_set_text(GTK_LABEL(priv->lblip), ipact);
  gtk_label_set_text(GTK_LABEL(priv->lblmac), macact);
  gtk_label_set_text(GTK_LABEL(priv->lblpuntoap), apact);

  gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(priv->prg), (100 - fabs(atof(vars.signal))) / 100);
  fprintf(stdout, "Fuerza wifi %s\n", vars.signal);

}

void asociar(void)
{
  
 if(vars.iniciado == 0) return;
  if(vars.net->cap.working == 1) return;
  if(net_isdown_interf (vars.net) == 1) return;
 if(strcmp(vars.signal, "Desconectado") == 0)
 {
   net_wifi_asoc_open(vars.net);
   fprintf(stdout, "ASOCIANDO A %s\n", vars.essidcli); 
 }
 else
 {
	    fprintf(stdout, "YA ASOCIANDO A %s\n", vars.essidcli); 
 }
}

static GtkWidget*
create_window (void)
{
	GtkWidget *window;
	GtkBuilder *builder;
	GError* error = NULL;



	/* Load UI from file */
	builder = gtk_builder_new ();
	if (!gtk_builder_add_from_file (builder, UI_FILE, &error))
	{
		g_critical ("Couldn't load builder file: %s", error->message);
		g_error_free (error);
	}

	/* Auto-connect signal handlers */
	gtk_builder_connect_signals (builder, NULL);

	/* Get the window object from the ui file */
	window = GTK_WIDGET (gtk_builder_get_object (builder, TOP_WINDOW));
        if (!window)
        {
                g_critical ("Widget \"%s\" is missing in file %s.",
				TOP_WINDOW,
				UI_FILE);
        }



	priv = g_malloc (sizeof (struct _Private));
	/* ANJUTA: Widgets initialization for autolnxinternet.ui - DO NOT REMOVE */
	priv->txtregion = GTK_WIDGET (gtk_builder_get_object(builder, "txtregion"));
	priv->txtrate = GTK_WIDGET (gtk_builder_get_object(builder, "txtrate"));
	priv->txtmtu = GTK_WIDGET (gtk_builder_get_object(builder, "txtmtu"));
	priv->lblpuntoap = GTK_WIDGET (gtk_builder_get_object(builder, "lblpuntoap"));
	priv->lblip = GTK_WIDGET (gtk_builder_get_object(builder, "lblip"));
	priv->lblmac = GTK_WIDGET (gtk_builder_get_object(builder, "lblmac"));

	priv->imgdisponib = GTK_WIDGET (gtk_builder_get_object(builder, "imgdisponib"));
	priv->lblssid = GTK_WIDGET (gtk_builder_get_object(builder, "lblssid"));
	priv->lblreint = GTK_WIDGET (gtk_builder_get_object(builder, "lblreint"));
	priv->txtnet = GTK_WIDGET (gtk_builder_get_object(builder, "txtnet"));
	priv->imgstatus = GTK_WIDGET (gtk_builder_get_object(builder, "imgstatus"));
	priv->txtcanalcon = GTK_WIDGET (gtk_builder_get_object(builder, "txtcanalcon"));
	priv->txtrts = GTK_WIDGET (gtk_builder_get_object(builder, "txtrts"));
	priv->txtfrag = GTK_WIDGET (gtk_builder_get_object(builder, "txtfrag"));
	priv->txtdns5 = GTK_WIDGET (gtk_builder_get_object(builder, "txtdns5"));
	priv->txtdns4 = GTK_WIDGET (gtk_builder_get_object(builder, "txtdns4"));
	priv->txtdns3 = GTK_WIDGET (gtk_builder_get_object(builder, "txtdns3"));
	priv->txtdns2 = GTK_WIDGET (gtk_builder_get_object(builder, "txtdns2"));
	priv->txtdns1 = GTK_WIDGET (gtk_builder_get_object(builder, "txtdns1"));
	priv->txtanclabssid = GTK_WIDGET (gtk_builder_get_object(builder, "txtanclabssid"));
	priv->txtnombrewifi = GTK_WIDGET (gtk_builder_get_object(builder, "txtnombrewifi"));
	priv->txtpuertocap = GTK_WIDGET (gtk_builder_get_object(builder, "txtpuertocap"));
	priv->txtnet = GTK_WIDGET (gtk_builder_get_object(builder, "txtnet"));
	priv->txtpasarl = GTK_WIDGET (gtk_builder_get_object(builder, "txtpasarl"));
	priv->__glade_unnamed_5 = GTK_WIDGET (gtk_builder_get_object(builder, "__glade_unnamed_5"));
	priv->prg = GTK_WIDGET (gtk_builder_get_object(builder, "prg"));
	priv->btnparar = GTK_WIDGET (gtk_builder_get_object(builder, "btnparar"));
	priv->btniniciar = GTK_WIDGET (gtk_builder_get_object(builder, "btniniciar"));
	priv->__glade_unnamed_11 = GTK_WIDGET (gtk_builder_get_object(builder, "__glade_unnamed_11"));
	priv->btnload = GTK_WIDGET (gtk_builder_get_object(builder, "btnload"));
	priv->btnsave = GTK_WIDGET (gtk_builder_get_object(builder, "btnsave"));
	priv->txtinterfpub = GTK_WIDGET (gtk_builder_get_object(builder, "txtinterfpub"));
	priv->lblsignal = GTK_WIDGET (gtk_builder_get_object(builder, "lblsignal"));
	priv->txtinterfcli = GTK_WIDGET (gtk_builder_get_object(builder, "txtinterfcli"));

	g_object_unref (builder);

	vars.iniciado = 0;
	return window;
}

int
main (int argc, char *argv[])
{
 	GtkWidget *window;


#ifdef ENABLE_NLS

	bindtextdomain (GETTEXT_PACKAGE, PACKAGE_LOCALE_DIR);
	bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
	textdomain (GETTEXT_PACKAGE);
#endif

    /* Desactivar el administrador de red antesde proceder */
    net_stop_nmanager();

	vars.home = g_get_home_dir();
	strcpy(vars.dirconf, vars.home);
	strcat(vars.dirconf, "/.autolnxconf");
	g_mkdir(vars.dirconf, 0777);

	sys_tcp_low_latency();

	
	gtk_init (&argc, &argv);
	

	window = create_window ();
	gtk_widget_show (window);

	gtk_main ();

/* Activar administrador de red antes de salir */
    net_start_nmanager();

	g_free (priv);

	system("reset"); /* Liberar terminal */
	remove("/tmp/datoswifi");
    remove("/tmp/lnxgoog");
	
	return 0;
}
